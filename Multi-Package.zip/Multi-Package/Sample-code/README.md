# Sample-code
A lightweight npm package that generates a pre-configured Express.js setup.
